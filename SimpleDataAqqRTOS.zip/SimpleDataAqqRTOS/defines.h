//expiratory flow rate calculattion
#define discharg_coefficient 0.95
#define fluid_density 1.25
#define area_constant 0.000066

//Waveform
#define CH_OFFSET 0
